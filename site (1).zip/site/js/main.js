$(document).ready(function(){
  
  $(".slider").owlCarousel({
		items: 1,
		loop: true,
		autoplay: true,
		autoplayTimeout: 3000
	});
  $('#top-btn').click(function(){
        $('html,body').animate({scrollTop : 0},800);
    });
});

$(window).scroll(function(){
    if($(this).scrollTop() > 40){
        $('#top-btn').fadeIn();
    }else{
        $('#top-btn').fadeOut();

    }
});